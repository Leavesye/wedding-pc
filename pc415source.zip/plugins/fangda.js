import Vue from 'vue'
import fangda from '@/components/fangda.vue'
Vue.component('fangda', fangda)