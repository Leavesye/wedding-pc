import Vue from 'vue'
import btns from '@/components/btns.vue'
Vue.component('btns', btns)