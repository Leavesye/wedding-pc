import Vue from 'vue'
import waterfall from 'vue-waterfall2'
Vue.use(waterfall)