import Vue from 'vue'
import VueAwesomeSwiper from 'vue-awesome-swiper/dist/ssr'

import VueAwesomeSwiper2 from 'vue-awesome-swiper'
Vue.use(VueAwesomeSwiper)
Vue.use(VueAwesomeSwiper2)