<style lang="scss" scoped></style>
<template>
  <div class="container">
    <nuxt-child></nuxt-child>
  </div>
</template>
<script>
export default {
  data() {
    return {}
  },
  async asyncData({ params, redirect }) {
    // redirect('/wedding/1')
    return
  },
  mounted() {},
  methods:{}
}
</script>
