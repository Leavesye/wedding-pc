<style lang="scss" scoped></style>
<template>
  <div class="container"></div>
</template>
<script>
export default {
  data() {
    return {}
  },
  async asyncData({ params }) {
    return {  }
  },
  mounted() {},
  methods:{}
}
</script>
