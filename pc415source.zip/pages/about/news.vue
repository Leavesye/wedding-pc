<template>
  <div class="wrap">
    <nuxt-child></nuxt-child>
  </div>
</template>
<script>
export default {
  data() {
    return {}
  },
  async asyncData({ params }) {
    return {}
  },
  mounted() {},
  methods: {}
}
</script>
